#!/bin/bash

# Compile
g++ -std=c++17 -O2 main.cpp -o main.out || { echo "❌ Compilation failed"; exit 1; }

echo "🚀 Running..."

# Run with time + memory stats
/usr/bin/time -f "\n⏱ Time: %E\n🧠 Memory: %M KB" ./main.out < input.txt > output.txt

# Show output
echo "===== OUTPUT ====="
cat output.txt

# Cleanup
rm -f main.out
