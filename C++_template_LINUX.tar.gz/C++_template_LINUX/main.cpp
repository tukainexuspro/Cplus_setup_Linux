#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    cin>>n;
    cout<<"HELLO WORLD "<<2*n;
    return 0;
}